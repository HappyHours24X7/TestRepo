package DemoOpenCart;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Tweet {
	
	static String driverPath = "D:\\Softwares\\geckodriver-v0.28.0-win64\\geckodriver.exe";
	WebDriver driver;
	@Test
	public void loginOpenCart() throws InterruptedException
	{	
		System.setProperty("webdriver.gecko.driver",driverPath);			
		driver = new FirefoxDriver();
		driver.get("https://demo.opencart.com/index.php?route=product/product&product_id=31&search=Nikon");
		
		String cartWindow = driver.getWindowHandle().toString();
				
		driver.findElement(By.xpath("//div[@class='tweet_iframe_widget']//span")).click();
		Thread.sleep(5000);
		driver.switchTo().window(driver.getWindowHandle());
		//driver.switchTo().window("PopupWindow");
		Thread.sleep(5000);
		System.out.println(driver.getTitle());
		WebElement text=driver.findElement(By.xpath("//span[contains(text(),'Want to log in first?')]"));
		System.out.println(text.getText());
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div[3]/div/div/div/div/div/div[2]/div[2]/div/div[2]/div[2]/div/span/span/span")).click();
		Thread.sleep(5000);
		
		driver.close();
		
		driver.switchTo().window(cartWindow);
		Thread.sleep(5000);
		driver.close();	
	}
	
}
