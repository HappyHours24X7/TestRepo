package DemoOpenCart;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class LogIn {
	public class JavaScriptExecutor {
		
		@Test
		public void Login() throws InterruptedException 
		{
			String driverPath = "D:\\Softwares\\geckodriver-v0.28.0-win64\\geckodriver.exe";
			System.setProperty("webdriver.gecko.driver", driverPath);	
			WebDriver driver= new FirefoxDriver();	
			driver.get("https://demo.opencart.com/index.php?route=account/login");
			
			
			JavascriptExecutor js= (JavascriptExecutor)driver;
			//WebElement EmailTxt= driver.findElement(By.name("email"));
			//WebElement PwdTxt= driver.findElement(By.name("password"));
			
			js.executeScript("alert('Welcome to demo open cart');");
			Thread.sleep(2000);
			Alert alt= driver.switchTo().alert();
			alt.accept();
			
					
			WebElement Login= driver.findElement(By.xpath("//input[@type='submit']"));
			
			js.executeScript("document.getElementById('input-email').value='happyhours@hotmail.com';");
			js.executeScript("document.getElementById('input-password').value='c#p@ss';");
			
			js.executeScript("arguments[0].click();",Login);
			
			Thread.sleep(3000);
			String sText= js.executeScript("return document.title;").toString();
			System.out.println("the page title is "+sText);
						
			//js.executeScript("arguments[0].value='saimanishkumar11@gmail.com'","arguments[1].value='Sairam@1998'","arguments[2].click();",EmailTxt,PwdTxt,Login);
			
			driver.quit();
		}
	}
}
