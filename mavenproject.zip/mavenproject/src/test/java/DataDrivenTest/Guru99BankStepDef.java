package DataDrivenTest; 

import java.util.List; 

import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.firefox.FirefoxDriver; 
import cucumber.annotation.en.Given; 
import cucumber.annotation.en.Then; 
import cucumber.annotation.en.When; 
import cucumber.table.DataTable; 

public class Guru99BankStepDef { 
   WebDriver driver = null;
	
   @Given("^User navigates to \"http://demo.guru99.com/V4\"$") 
   public void gotoGuru99Bank(){ 
	   System.setProperty("webdriver.gecko.driver","D:\\Softwares\\geckodriver-v0.28.0-win64\\geckodriver.exe");
	  driver = new FirefoxDriver();
	  driver.navigate().to("http://demo.guru99.com/V4"); 
	  System.out.println("guru99Bank"); 
   } 
	
   @When("^User enters valid credentials$") 
   public void valid_credentials(DataTable table){ 
      //Initialize data table 
	   List<String> data = table.asList(null);
	   //List<List<String>> data = table.raw();
	   System.out.println(data.get(0));  
      
      //Enter data
      driver.findElement(By.name("txtUsername")).sendKeys(data.get(0));
      driver.findElement(By.name("txtPassword")).sendKeys(data.get(1));
      driver.findElement(By.name("Submit")).click(); 
     } 
	
   @Then("^User Login Successful$") 
   public void Login_Successful() {
      if(driver.getCurrentUrl().equalsIgnoreCase("http://demo.guru99.com/V4/manager/Managerhomepage.php")){
         System.out.println("Login Passed"); 
      } else { 
         System.out.println("Login Failed"); 
      } 
      driver.close(); 
   } 
}