package DataDrivenTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class ReadXML {
	static String driverPath = "D:\\Softwares\\geckodriver-v0.28.0-win64\\geckodriver.exe";
	WebDriver driver;
	
	@Test()
	@Parameters({"sUsername", "sPassword"})
	public void login(@Optional("mngr294620")String sUsername,@Optional("ehYbydU") String sPassword)
	{
		
		System.setProperty("webdriver.gecko.driver",driverPath);			
		driver = new FirefoxDriver();
		driver.get("http://demo.guru99.com/V4/");
		driver.findElement(By.name("uid")).sendKeys(sUsername);
		driver.findElement(By.name("password")).sendKeys(sPassword);
		driver.findElement(By.name("btnLogin")).click();
		System.out.println("Logged In!!!");
		driver.close();
		
	}
}
