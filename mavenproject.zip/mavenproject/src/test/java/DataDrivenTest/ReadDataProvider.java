package DataDrivenTest;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


public class ReadDataProvider {
	
	static String driverPath = "D:\\Softwares\\geckodriver-v0.28.0-win64\\geckodriver.exe";
	
	@DataProvider(name="Testdata")
	public Object[][] getData()
	{
		Object[][] data = new Object[3][2];// 2 dimentional array rows and col
		//row 1 data
		data[0][0]="mngr294620";
		data[0][1]="ehYbydU";
		//row 2 data
		data[1][0]="mngr294620";
		data[1][1]="ehYbydU";
		//row 2 data
		data[2][0]="mngr294620";
		data[2][1]="ehYbydU";
		return data;
	}
	@Test(dataProvider="Testdata")
	public void Loginvalidation(String username, String password)
	{
		System.setProperty("webdriver.gecko.driver",driverPath);			
		WebDriver driver = new FirefoxDriver();
		driver.get("http://demo.guru99.com/V4/");
		driver.findElement(By.name("uid")).sendKeys(username);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("btnLogin")).click();
		driver.close();
	}

}

