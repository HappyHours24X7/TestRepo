Feature: User Log in to Guru99 Bank
Background: User is already registered with Guru99 Bank
Scenario: Successful Login
	Given User navigates to "http://demo.guru99.com/V4"
	When User enters valid credentials
	|mngr290011|tyjymas|
	|mngr290453|AmYtapy|
	|mngr290454|EqYtybA|

	Then User Login Successful
	
