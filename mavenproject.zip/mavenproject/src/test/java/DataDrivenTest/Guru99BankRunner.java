package DataDrivenTest;
	
import org.junit.runner.RunWith; 
import cucumber.junit.Cucumber; 

@RunWith(Cucumber.class)				
@Cucumber.Options(format = {"pretty","html:target/Destination"},
features= "DataDrivenTest",
glue="DataDrivenTest",
monochrome=true
)

public class Guru99BankRunner				
{		

}