package Guru99POM;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Guru99POM.Guru99HomePage;
import Guru99POM.Guru99Login;

public class Test99GuruLogin {

    String driverPath = "D:\\Softwares\\geckodriver-v0.28.0-win64\\geckodriver.exe";
    WebDriver driver;
    Guru99Login objLogin;
    Guru99HomePage objHomePage;

    @BeforeTest
    public void setup(){
	System.setProperty("webdriver.gecko.driver", driverPath);
        driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("http://demo.guru99.com/V4/");
    }

    
    @Test(priority=0)
    public void test_Home_Page_Appear_Correct(){
        
    //Create Login Page object
    objLogin = new Guru99Login(driver);

    //Verify login page title
    String loginPageTitle = objLogin.getLoginTitle();
    Assert.assertTrue(loginPageTitle.toLowerCase().contains("guru99 bank"));

    //login to application
    objLogin.loginToGuru99("mngr294620", "ehYbydU");

    // go the next page
    objHomePage = new Guru99HomePage(driver);

    //Verify home page
    Assert.assertTrue(objHomePage.getHomePageDashboardUserName().toLowerCase().contains("manger id : mngr294620"));
    System.out.println("Successfully Logged in to Guru99Bank!!");
    driver.close();
    
    }
    
}