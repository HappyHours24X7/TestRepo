package PageFactory;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;

import org.testng.Assert;

import org.testng.annotations.BeforeTest;

import org.testng.annotations.Test;

import PageFactory.HomePage;
import PageFactory.LoginPage;

public class OHRMTest {

    String driverPath = "D:\\Softwares\\geckodriver-v0.28.0-win64\\geckodriver.exe";
    
    WebDriver driver;

    LoginPage objLogin;

    HomePage objHomePage; 

    @BeforeTest

    public void setup(){

        System.setProperty("webdriver.gecko.driver", driverPath);
        
        driver = new FirefoxDriver();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        driver.get("https://opensource-demo.orangehrmlive.com/");

    }

    /*This test go to http://demo.guru99.com/V4/

     * Verify login page title as guru99 bank

     * Login to application

     * Verify the home page using Dashboard message*/

    @Test(priority=0)

    public void test_Home_Page_Appear_Correct(){

    //Create Login Page object

    objLogin = new LoginPage(driver);

    //login to application

    objLogin.loginToOHRM("Admin", "admin123");

    // go the next page

    objHomePage = new HomePage(driver);

    //Verify home page

    Assert.assertTrue(objHomePage.getHomePageDashboardUserName().contains("^Welcome.*"));
    driver.close();
    }

}