package Guru99PageFactory;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Guru99PageFactory.HomePageFactory;
import Guru99PageFactory.LoginPageFactory;

public class TestPageFactory {

    String driverPath = "D:\\Softwares\\geckodriver-v0.28.0-win64\\geckodriver.exe";
    
    WebDriver driver;
    LoginPageFactory objLogin;
    HomePageFactory objHomePage; 

    @BeforeTest
    public void setup(){
        System.setProperty("webdriver.gecko.driver", driverPath);
        driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("http://demo.guru99.com/V4/");
    }

    /**
     * This test go to http://demo.guru99.com/V4/
     * Verify login page title as guru99 bank
     * Login to application
     * Verify the home page using Dashboard message
     */

    @Test(priority=0)
    public void test_Home_Page_Appear_Correct(){
     //Create Login Page object
    objLogin = new LoginPageFactory(driver);
    //Verify login page title
    String loginPageTitle = objLogin.getLoginTitle();
    Assert.assertTrue(loginPageTitle.toLowerCase().contains("guru99 bank"));
    
    //login to application
    objLogin.loginToGuru99("mngr294620", "ehYbydU");
    
    // go the next page
    objHomePage = new HomePageFactory(driver);
    //Verify home page
    Assert.assertTrue(objHomePage.getHomePageDashboardUserName().toLowerCase().contains("manger id : mngr290011"));
    driver.close();
    }
}