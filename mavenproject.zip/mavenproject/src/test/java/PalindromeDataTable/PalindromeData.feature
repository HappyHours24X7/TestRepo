Feature: Palindrome Validation
Scenario: Check if String is Palindrome
    Given I entered word <wordToTest>
    | wordToTest |
    | "madam"    |
    | "radar"    |
    | "Space"    |
    | "level"    |
    When I test it for Palindrome
    Then the output should be <output>
	| output  |
	| "true"  |
	| "false" |
	| "false" |
	| "true"  |